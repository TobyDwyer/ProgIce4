﻿public class Program
{
    public static void Main( string[] args )
    {
        while (true)
        {
            Console.WriteLine("Enter a string to find its permutations (or type 'exit' to quit):");
            string input = Console.ReadLine();

            if (input.ToLower() == "exit")
                break;

            var result = findPerms(input);
            Console.WriteLine($"Permutations of '{input}':");
            foreach (var perm in result)
            {
                Console.WriteLine(perm);
            }

            Console.WriteLine();
        }
    }



    public static List<string> findPerms( string s )
    {
        if (s.Length == 1)
            return new List<string> { s };

        var all = new List<string>();

        for (int i = 0; i < s.Length; i++)
        {
            char curLet = s[i];
            var remLet = s.Substring(0, i) + s.Substring(i + 1);
            var permsRem = findPerms(remLet);

            foreach (var subperms in permsRem)
            {
                all.Add(curLet + subperms);
            }

        }

        return all;

    }
}